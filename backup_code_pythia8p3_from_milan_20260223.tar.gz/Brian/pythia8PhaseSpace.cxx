// Generate Pythia events and test kinematics

#include "Pythia8/Pythia.h"

#include<iostream>
using std::cout;
using std::cerr;
using std::endl;

#include<string>
using std::string;

#include "TFile.h"
#include "TH1.h"
#include "TH2.h"
#include "TH3.h"
#include "TMath.h"
#include "TVector2.h"
#include "TVector3.h"
#include "TProfile2D.h"

using namespace Pythia8;

int main(int argc, char* argv[])
{
  if(argc != 3) // 7
    {
      cerr << "Wrong number of arguments" << endl;
      cerr << "program.exe steer out.hist.root" << endl;
      exit(EXIT_FAILURE);
    }

  const char* rootOut = argv[2];
  cout << "Steering File = " << argv[1] << endl;
  cout << "Root Output = " << rootOut << endl;

  // Open Root File
  TFile *ofile = TFile::Open(rootOut,"recreate");

  // Histos
  Int_t BINS = 100;
  const Double_t xbin[101] = { 0.001,0.00112202,0.00125893,0.00141254,0.00158489,0.00177828,0.00199526,0.00223872,0.00251189,0.00281838,0.00316228,0.00354813,0.00398107,0.00446684,0.00501187,0.00562341,0.00630957,0.00707946,0.00794328,0.00891251,0.01,0.0112202,0.0125893,0.0141254,0.0158489,0.0177828,0.0199526,0.0223872,0.0251189,0.0281838,0.0316228,0.0354813,0.0398107,0.0446684,0.0501187,0.0562341,0.0630957,0.0707946,0.0794328,0.0891251,0.1,0.112202,0.125893,0.141254,0.158489,0.177828,0.199526,0.223872,0.251189,0.281838,0.316228,0.354813,0.398107,0.446684,0.501187,0.562341,0.630957,0.707946,0.794328,0.891251,1,1.12202,1.25893,1.41254,1.58489,1.77828,1.99526,2.23872,2.51189,2.81838,3.16228,3.54813,3.98107,4.46684,5.01187,5.62341,6.30957,7.07946,7.94328,8.91251,10,11.2202,12.5893,14.1254,15.8489,17.7828,19.9526,22.3872,25.1189,28.1838,31.6228,35.4813,39.8107,44.6684,50.1187,56.2341,63.0957,70.7946,79.4328,89.1251,100.0 };

  TH1D *xsecQ2_dis = new TH1D("xsecQ2_dis","",130,-10.,3.);

  TH1D *q2Hist = new TH1D("q2Hist","Log Q2",130,-10.,3.);
  TH1D *yHist = new TH1D("yHist","Inelasticity",1000,-5.,0.);
  TH2D *phaseSpaceHist = new TH2D("phaseSpace","Log Q2 Vs Log x",100,-9.,1.,200,-5.,4.);
  TH2D *phaseSpaceAltHist = new TH2D("phaseSpaceAlt","Log Q2 Vs Log x",200,-20.,1.,300,-9.,4.);
  TH2D *phaseSpaceTrueHist = new TH2D("phaseSpaceTrue","Log Q2 Vs Log x",100,-9.,1.,200,-5.,4.);
  
  TH1D *sHat = new TH1D("sHat","Event sHat",1000,0.,1000);
  TH1D *ptHat = new TH1D("ptHat","Event PtHat",500,0.,50.);
  TH1D *w2Hist = new TH1D("w2Hist","W2",4000,0.,1000.);
  
  TH2D *phaseSpaceFullTrueBadXHist = new TH2D("phaseSpaceFullTrueBadX","Log Q2 Vs Log x",100,-9.,1.,200,-5.,4.);

  TH2D *phaseSpacePurityNumHist = new TH2D("phaseSpacePurityNum","",100,-9.,1.,200,-5.,4.);
  TH2D *phaseSpacePurityDenHist = new TH2D("phaseSpacePurityDen","",100,-9.,1.,200,-5.,4.);


  TH2D *testQ2DiffVsQ2 = new TH2D("testQ2DiffVsQ2","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testQ2DiffVsX = new TH2D("testQ2DiffVsX","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2 = new TH2D("testXDiffVsQ2","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsX = new TH2D("testXDiffVsX","",100,-9.,1.,10000,-0.5,0.5);

  TH2D *testXDiffVsQ2Corrected = new TH2D("testXDiffVsQ2Corrected","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2LightCorrected = new TH2D("testXDiffVsQ2LightCorrected","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2StrangeCorrected = new TH2D("testXDiffVsQ2StrangeCorrected","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2CharmCorrected = new TH2D("testXDiffVsQ2CharmCorrected","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2BottomCorrected = new TH2D("testXDiffVsQ2BottomCorrected","",200,-5.,4.,10000,-0.5,0.5);

  TH2D *testXDiffVsXCorrected = new TH2D("testXDiffVsXCorrected","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsXLightCorrected = new TH2D("testXDiffVsXLightCorrected","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsXStrangeCorrected = new TH2D("testXDiffVsXStrangeCorrected","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsXCharmCorrected = new TH2D("testXDiffVsXCharmCorrected","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsXBottomCorrected = new TH2D("testXDiffVsXBottomCorrected","",100,-9.,1.,10000,-0.5,0.5);

  TH2D *testQ2DiffVsXLight = new TH2D("testQ2DiffVsXLight","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testQ2DiffVsXStrange = new TH2D("testQ2DiffVsXStrange","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testQ2DiffVsXCharm = new TH2D("testQ2DiffVsXCharm","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testQ2DiffVsXBottom = new TH2D("testQ2DiffVsXBottom","",100,-9.,1.,10000,-0.5,0.5);

  TH2D *testXDiffVsQ2Light = new TH2D("testXDiffVsQ2Light","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Strange = new TH2D("testXDiffVsQ2Strange","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Charm = new TH2D("testXDiffVsQ2Charm","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Bottom = new TH2D("testXDiffVsQ2Bottom","",200,-5.,4.,10000,-0.5,0.5);

  TProfile2D *testQ2DiffVsPhaseSpace = new TProfile2D("testQ2DiffVsPhaseSpace","",500,-9.,1.,500,-5.,5.);
  TProfile2D *testXDiffVsPhaseSpace = new TProfile2D("testXDiffVsPhaseSpace","",500,-9.,1.,500,-5.,5.);

  TH2D *testQ2DiffVsQ2Stable = new TH2D("testQ2DiffVsQ2Stable","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testQ2DiffVsXStable = new TH2D("testQ2DiffVsXStable","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Stable = new TH2D("testXDiffVsQ2Stable","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testXDiffVsXStable = new TH2D("testXDiffVsXStable","",100,-9.,1.,10000,-0.5,0.5);

  TProfile2D *testQ2DiffVsPhaseSpaceStable = new TProfile2D("testQ2DiffVsPhaseSpaceStable","",500,-9.,1.,500,-5.,5.);
  TProfile2D *testXDiffVsPhaseSpaceStable = new TProfile2D("testXDiffVsPhaseSpaceStable","",500,-9.,1.,500,-5.,5.);


  TH2D *testQ2DiffVsXBand0 = new TH2D("testQ2DiffVsXBand0","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Band0 = new TH2D("testXDiffVsQ2Band0","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testRecoVsTrueQ2Band0 = new TH2D("testRecoVsTrueQ2Band0","",2000,0.,4.,2000,0.,4.);

  TProfile2D *testQ2DiffVsPhaseSpaceBand0 = new TProfile2D("testQ2DiffVsPhaseSpaceBand0","",500,-9.,1.,500,-5.,5.);
  TProfile2D *testXDiffVsPhaseSpaceBand0 = new TProfile2D("testXDiffVsPhaseSpaceBand0","",500,-9.,1.,500,-5.,5.);

  TH2D *testXDiffVsQ2Band0Bin0 = new TH2D("testXDiffVsQ2Band0Bin0","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testRecoVsTrueQ2Band0Bin0 = new TH2D("testRecoVsTrueQ2Band0Bin0","",2000,0.,4.,2000,0.,4.);


  TH2D *testQ2DiffVsXBand1 = new TH2D("testQ2DiffVsXBand1","",100,-9.,1.,10000,-0.5,0.5);
  TH2D *testXDiffVsQ2Band1 = new TH2D("testXDiffVsQ2Band1","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testRecoVsTrueQ2Band1 = new TH2D("testRecoVsTrueQ2Band1","",2000,0.,4.,2000,0.,4.);

  TProfile2D *testQ2DiffVsPhaseSpaceBand1 = new TProfile2D("testQ2DiffVsPhaseSpaceBand1","",500,-9.,1.,500,-5.,5.);
  TProfile2D *testXDiffVsPhaseSpaceBand1 = new TProfile2D("testXDiffVsPhaseSpaceBand1","",500,-9.,1.,500,-5.,5.);

  TH2D *testXDiffVsQ2Band1Bin0 = new TH2D("testXDiffVsQ2Band1Bin0","",200,-5.,4.,10000,-0.5,0.5);
  TH2D *testRecoVsTrueQ2Band1Bin0 = new TH2D("testRecoVsTrueQ2Band1Bin0","",2000,0.,4.,2000,0.,4.);


  TH2D *testRecoVsTrueQ2 = new TH2D("testRecoVsTrueQ2","",2000,0.,4.,2000,0.,4.);


  TH1D *testCalcRecoEtaDiff = new TH1D("testCalcRecoEtaDiff","",200000,-0.1,0.1);
  TH1D *testCalcRecoEDiff = new TH1D("testCalcRecoEDiff","",200000,-1.0,1.0);

  TH1D *testCalcTrueEtaDiff = new TH1D("testCalcTrueEtaDiff","",200000,-0.1,0.1);
  TH1D *testCalcTrueEDiff = new TH1D("testCalcTrueEDiff","",200000,-1.0,1.0);

  TH2D *testCalcTrueEtaVsEDiff = new TH2D("testCalcTrueEtaVsEDiff","",2000,-1.,1.,2000,-0.1,0.1);


  TH2D *partMomVsEtaBeamElecLogHist = new TH2D("partMomVsEtaBeamElecLog","",100,-5.,5.,BINS,xbin);
  TH2D *partEVsEtaBeamElecLogHist = new TH2D("partEVsEtaBeamElecLog","",200,-10.,10.,BINS,xbin);
  TH2D *partEVsEtaBeamElecAltLogHist = new TH2D("partEVsEtaBeamElecAltLog","",200,-10.,10.,BINS,xbin);
  TH2D *partEVsEtaBeamElecCutLogHist = new TH2D("partEVsEtaBeamElecCutLog","",200,-10.,10.,BINS,xbin);
  TH2D *partEVsEtaBeamElecBadXLogHist = new TH2D("partEVsEtaBeamElecBadXLog","",200,-10.,10.,BINS,xbin);
  



  // Set Up Pythia Event
  Pythia8::Pythia p8;
  Pythia8::Event &event = p8.event;

  // Read in Steering File & Make Other Settings
  p8.readFile(argv[1]);
  p8.readString("Main:timesAllowErrors = 10000"); // allow more errors, eP is brittle

  //double bottomMassOld = p8.particleData.m0(5);
  //cout << "!!!!! Original Bottom Mass = " << bottomMassOld << " !!!!!" << endl;

  
  //p8.particleData.m0(1,0.00);
  //p8.particleData.m0(2,0.00);
  //p8.particleData.m0(3,0.00);
  //p8.particleData.m0(4,0.00);
  //p8.particleData.m0(5,0.00);

  //p8.particleData.m0(2212,0.00);
  
  //p8.particleData.m0(11,0.00);
  

  //double bottomMassNew = p8.particleData.m0(-5);
  //cout << "!!!!! New Bottom Mass = " << bottomMassNew << " !!!!!" << endl;

  // Initialize Pythia
  p8.init();


  // Record Nominal COM Energy
  double eCMnom = p8.info.eCM();

  int numPrint = 0;

  // Run
  int nevents = p8.mode("Main:numberOfEvents");
  for(int ev=0; ev<nevents; ev++)
    {
      if(!p8.next()) continue;

      // Modified COM Energy
      double eCMnow = p8.info.eCM();

      // Find Electron and Other Tests
      // Should work for process != 211
      int indexeOut = -1;
      bool elecFound = true;
      bool stableElec = false;
      //int has71 = false;
      double minDeltaQ2 = 10000.0;
      double minQ2 = -999.;
      int minQ2Index = -1;
      for(int i=0; i < p8.event.size(); i++)
	{
	  if(p8.event[i].id() == 11 && TMath::Abs(p8.event[i].status()) == 23) indexeOut = i;
	  if(i == 6 && p8.event[i].id() == 11 && p8.event[i].status() > 0) stableElec = true;
	  //if(p8.event[i].status() == -71) has71 = true;

	  if(p8.event[i].id() == 11)
	    {
	      Pythia8::Vec4 tmpPhoton = event[2].p() - event[i].p();
	      double tmpQ2 = -tmpPhoton.m2Calc();
	      double deltaQ2 = TMath::Abs(tmpQ2 + 1.0*p8.info.tHat());
	      
	      if(deltaQ2 < minDeltaQ2)
		{
		  minDeltaQ2 = deltaQ2;
		  minQ2 = tmpQ2;
		  minQ2Index = i;
		}
	    }

	  //cout << setprecision(10) << ev << " " << p8.info.code() << " " << i << " " << p8.event[i].id() << " " << p8.event[i].status() << " " << p8.event[i].mother1() << " " << p8.event[i].mother2() << " " << p8.event[i].px() << " " << p8.event[i].py() << " " << p8.event[i].pz() << " " << p8.event[i].e() << endl;
	}

      if(indexeOut == -1)
	{
	  //cout << "!!!!! NO ELECTRON !!!!!" << endl;
	  elecFound = false;
	  indexeOut = 6;
	}

      // Four-momenta of proton, electron, virtual photon/Z^0/W^+-.
      Pythia8::Vec4 pProton = event[1].p();
      Pythia8::Vec4 peIn    = event[2].p(); // Was 2
      Pythia8::Vec4 peOutAlt   = event[minQ2Index].p(); //indexeOut
      Pythia8::Vec4 peOut   = event[6].p();
      Pythia8::Vec4 pPhoton = peIn - peOut;
      Pythia8::Vec4 pPhotonAlt = peIn - peOutAlt;

      // Q2, W2, Bjorken x, y.
      double Q2    = - pPhoton.m2Calc();
      double Q2Alt = -pPhotonAlt.m2Calc();
      double W2    = (pProton + pPhoton).m2Calc();
      double x     = Q2 / (2. * pProton * pPhoton);
      double xAlt  = Q2Alt / (2. * pProton * pPhotonAlt);
      double y     = (pProton * pPhoton) / (pProton * peIn);
      double yAlt  = (pProton * pPhotonAlt) / (pProton * peIn);

      double trueQ2 = -1.0*p8.info.tHat();
      double trueX = p8.info.x1();

      xsecQ2_dis->Fill(std::log10(trueQ2));
      

      // Event Level
      q2Hist->Fill(std::log10(Q2));
      yHist->Fill(std::log10(y));
      phaseSpaceHist->Fill(std::log10(x),std::log10(Q2));
      phaseSpaceAltHist->Fill(std::log10(xAlt),std::log10(Q2Alt));
      phaseSpaceTrueHist->Fill(std::log10(trueX),std::log10(trueQ2));
      sHat->Fill(p8.info.sHat());
      ptHat->Fill(p8.info.pTHat());
      w2Hist->Fill(W2);
      if(x > 1.0) phaseSpaceFullTrueBadXHist->Fill(std::log10(p8.info.x1()),std::log10(-1.0*p8.info.tHat()));

      
      // Electron Eta-Energy
      double yTrue = (-1.0*p8.info.tHat())/((4.0*18.0*275.0 - 0.93827*0.93827 - 0.000511*0.000511)*p8.info.x1());
      double xiTrue = 4*18.0*18.0*(1.0 - yTrue)/(-1.0*p8.info.tHat());
      double ATrue = (xiTrue - 1.0)/(xiTrue + 1.0);
      double calcEtaTrue = std::log(TMath::Tan(0.5*TMath::ACos(ATrue)));
      double calcETrue = ((-1.0*p8.info.tHat())/(2.0*18.0))*(1.0/(1.0 - TMath::Cos(2.0*TMath::ATan(TMath::Exp(calcEtaTrue)))));

      double xiReco = 4*18.0*18.0*(1.0 - y)/Q2;
      double AReco = (xiReco - 1.0)/(xiReco + 1.0);
      double calcEtaReco = std::log(TMath::Tan(0.5*TMath::ACos(AReco)));
      double calcEReco = (Q2/(2.0*18.0))*(1.0/(1.0 - TMath::Cos(2.0*TMath::ATan(TMath::Exp(calcEtaReco)))));

      int truePhaseSpaceBin = phaseSpacePurityNumHist->FindBin(std::log10(p8.info.x1()),std::log10(-1.0*p8.info.tHat()));
      int recoPhaseSpaceBin = phaseSpacePurityNumHist->FindBin(std::log10(x),std::log10(Q2));
      if(truePhaseSpaceBin == recoPhaseSpaceBin)
	{
	  phaseSpacePurityNumHist->Fill(std::log10(p8.info.x1()),std::log10(-1.0*p8.info.tHat()));
	}
      phaseSpacePurityDenHist->Fill(std::log10(x),std::log10(Q2));

      
      // X - Q2 Differences
      testQ2DiffVsQ2->Fill(std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
      testQ2DiffVsX->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);
      testXDiffVsQ2->Fill(std::log10(trueQ2),(x-trueX)/trueX);
      testXDiffVsX->Fill(std::log10(trueX),(x-trueX)/trueX);

      // Mass Corrected X Differences
      int struckQuarkID = TMath::Abs(p8.event[3].id());
      double struckQuarkMass = p8.particleData.m0(struckQuarkID);
      double corrX = x*(1.0 + (struckQuarkMass*struckQuarkMass)/Q2);

      testXDiffVsQ2Corrected->Fill(std::log10(trueQ2),(corrX-trueX)/trueX);
      if(struckQuarkID < 3) testXDiffVsQ2LightCorrected->Fill(std::log10(trueQ2),(corrX-trueX)/trueX);
      if(struckQuarkID == 3) testXDiffVsQ2StrangeCorrected->Fill(std::log10(trueQ2),(corrX-trueX)/trueX);
      if(struckQuarkID == 4) testXDiffVsQ2CharmCorrected->Fill(std::log10(trueQ2),(corrX-trueX)/trueX);
      if(struckQuarkID == 5) testXDiffVsQ2BottomCorrected->Fill(std::log10(trueQ2),(corrX-trueX)/trueX);

      testXDiffVsXCorrected->Fill(std::log10(trueX),(corrX-trueX)/trueX);
      if(struckQuarkID < 3) testXDiffVsXLightCorrected->Fill(std::log10(trueX),(corrX-trueX)/trueX);
      if(struckQuarkID == 3) testXDiffVsXStrangeCorrected->Fill(std::log10(trueX),(corrX-trueX)/trueX);
      if(struckQuarkID == 4) testXDiffVsXCharmCorrected->Fill(std::log10(trueX),(corrX-trueX)/trueX);
      if(struckQuarkID == 5) testXDiffVsXBottomCorrected->Fill(std::log10(trueX),(corrX-trueX)/trueX);

      if(TMath::Abs(p8.event[3].id()) < 3) testQ2DiffVsXLight->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);
      if(TMath::Abs(p8.event[3].id()) == 3) testQ2DiffVsXStrange->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);
      if(TMath::Abs(p8.event[3].id()) == 4) testQ2DiffVsXCharm->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);
      if(TMath::Abs(p8.event[3].id()) == 5) testQ2DiffVsXBottom->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);

      if(TMath::Abs(p8.event[3].id()) < 3) testXDiffVsQ2Light->Fill(std::log10(trueQ2),(x-trueX)/trueX);
      if(TMath::Abs(p8.event[3].id()) == 3) testXDiffVsQ2Strange->Fill(std::log10(trueQ2),(x-trueX)/trueX);
      if(TMath::Abs(p8.event[3].id()) == 4) testXDiffVsQ2Charm->Fill(std::log10(trueQ2),(x-trueX)/trueX);
      if(TMath::Abs(p8.event[3].id()) == 5) testXDiffVsQ2Bottom->Fill(std::log10(trueQ2),(x-trueX)/trueX);

      testQ2DiffVsPhaseSpace->Fill(std::log10(trueX),std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
      testXDiffVsPhaseSpace->Fill(std::log10(trueX),std::log10(trueQ2),(x-trueX)/trueX);

      if(stableElec) 
	{
	  testQ2DiffVsQ2Stable->Fill(std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
	  testQ2DiffVsXStable->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2);
	  testXDiffVsQ2Stable->Fill(std::log10(trueQ2),(x-trueX)/trueX);
	  testXDiffVsXStable->Fill(std::log10(trueX),(x-trueX)/trueX);

	  testQ2DiffVsPhaseSpaceStable->Fill(std::log10(trueX),std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
	  testXDiffVsPhaseSpaceStable->Fill(std::log10(trueX),std::log10(trueQ2),(x-trueX)/trueX);
	}


      bool band0 = false;
      bool band1 = false;
      if(std::log10(trueX) > -1.4 && (Q2-trueQ2)/trueQ2 < -0.004) band0 = true;
      if(std::log10(trueX) > -2.4 && std::log10(trueX) < -1.4 && (Q2-trueQ2)/trueQ2 < -0.03) band0 = true;
      if(std::log10(trueX) > -1.0 && (Q2-trueQ2)/trueQ2 < -0.0002 && (Q2-trueQ2)/trueQ2 > -0.002) band1 = true;
      if(std::log10(trueX) > -1.8 && std::log10(trueX) < -1.0 && (Q2-trueQ2)/trueQ2 < -0.001 && (Q2-trueQ2)/trueQ2 > -0.008) band1 = true;
      if(std::log10(trueX) > -2.7 && std::log10(trueX) < -1.8 && (Q2-trueQ2)/trueQ2 < -0.007 && (Q2-trueQ2)/trueQ2 > -0.07) band1 = true;
      if(std::log10(trueX) < -2.7 && (Q2-trueQ2)/trueQ2 < -0.04) band1 = true;

      if(band0)
	{
	  testQ2DiffVsXBand0->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2); // + 1.0*p8.info.tHat())/(-1.0*p8.info.tHat()));
	  testXDiffVsQ2Band0->Fill(std::log10(trueQ2),(x-trueX)/trueX);
	  testRecoVsTrueQ2Band0->Fill(std::log10(trueQ2),std::log10(Q2));

	  testQ2DiffVsPhaseSpaceBand0->Fill(std::log10(trueX),std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
	  testXDiffVsPhaseSpaceBand0->Fill(std::log10(trueX),std::log10(trueQ2),(x-trueX)/trueX);

	  if(std::log10(trueX) < -1.8 && std::log10(trueX) > -2.0)
	    {
	      testXDiffVsQ2Band0Bin0->Fill(std::log10(trueQ2),(x-trueX)/trueX);
	      testRecoVsTrueQ2Band0Bin0->Fill(std::log10(trueQ2),std::log10(Q2));
	    }
	}

      if(band1)
	{
	  testQ2DiffVsXBand1->Fill(std::log10(trueX),(Q2-trueQ2)/trueQ2); // + 1.0*p8.info.tHat())/(-1.0*p8.info.tHat()));
	  testXDiffVsQ2Band1->Fill(std::log10(trueQ2),(x-trueX)/trueX);
	  testRecoVsTrueQ2Band1->Fill(std::log10(trueQ2),std::log10(Q2));
	  
	  testQ2DiffVsPhaseSpaceBand1->Fill(std::log10(trueX),std::log10(trueQ2),(Q2-trueQ2)/trueQ2);
	  testXDiffVsPhaseSpaceBand1->Fill(std::log10(trueX),std::log10(trueQ2),(x-trueX)/trueX);
	  
	  if(std::log10(trueX) < -1.8 && std::log10(trueX) > -2.0)
	    {
	      testXDiffVsQ2Band1Bin0->Fill(std::log10(trueQ2),(x-trueX)/trueX);
	      testRecoVsTrueQ2Band1Bin0->Fill(std::log10(trueQ2),std::log10(Q2));
	    }
	}
      
      testRecoVsTrueQ2->Fill(std::log10(-1.0*p8.info.tHat()),std::log10(Q2));
      

      // Expected Vs Actual Electron Kinematics
      testCalcRecoEtaDiff->Fill(calcEtaReco - event[6].eta());
      testCalcRecoEDiff->Fill(calcEReco - event[6].e());

      testCalcTrueEtaDiff->Fill(calcEtaTrue - event[6].eta());
      testCalcTrueEDiff->Fill(calcETrue - event[6].e());

      testCalcTrueEtaVsEDiff->Fill(calcETrue - event[6].e(),calcEtaTrue - event[6].eta());

      
      // Electron Kinematics
      partMomVsEtaBeamElecLogHist->Fill(p8.event[6].eta(),TMath::Sqrt(p8.event[6].px()*p8.event[6].px() + p8.event[6].py()*p8.event[6].py() + p8.event[6].pz()*p8.event[6].pz()));
      partEVsEtaBeamElecLogHist->Fill(p8.event[6].eta(),p8.event[6].e());
      partEVsEtaBeamElecAltLogHist->Fill(p8.event[indexeOut].eta(),p8.event[indexeOut].e());
      if(x > 1.0) partEVsEtaBeamElecBadXLogHist->Fill(p8.event[6].eta(),p8.event[6].e());
      
      

      
    }

  // List Statistics  
  p8.stat();
  
  // Write and Close Root File
  ofile->Write();
  ofile->Close();
  // Done.
  return 0;

					  
}
