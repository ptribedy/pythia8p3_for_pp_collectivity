#!/bin/bash

# ============================================================================== 
# STAR SUBMIT SCRIPT (Fixed for File Processing)
# Usage: ./submit_job.sh root
# ==============================================================================

if [[ -z "$1" ]]; then
    echo "Usage: $0 [root]"
    exit 1
fi

MODE="$1"
WORK_DIR="$(pwd)"
OUT_DIR="/star/data05/scratch/ptribedy/pythia_pp200"

echo "[i] OUT_DIR: ${OUT_DIR}"

# ============================================================================== 
# MODE: CONVERT LOGS TO ROOT
# ==============================================================================
if [[ "$MODE" == "root" ]]; then

    if [[ ! -f "${WORK_DIR}/log_to_root.C" ]]; then
        echo "[!] log_to_root.C not found! Please create it first."
        exit 1
    fi

    mkdir -p "${OUT_DIR}/log"
    mkdir -p "${OUT_DIR}/sched"

    # ------------------------------------------------------------------
    # The XML Structure
    # FIXES:
    # 1. Removed comments with angle brackets < > to satisfy XML parser.
    # 2. Used maxFilesPerProcess="1" to run one job per log file.
    # ------------------------------------------------------------------
    cat <<EOF > "${WORK_DIR}/simple_root.xml"
<?xml version="1.0" encoding="utf-8"?>
<job name="PythiaRoot" maxFilesPerProcess="1" fileListSyntax="paths" simulateSubmission="false">

    <command>
        setup 64bits
        setup nfs4
        
        # INPUTFILE0 is the full path to the log file provided by scheduler
        echo "Processing: \$INPUTFILE0"

        # Copy the macro locally
        cp ${WORK_DIR}/log_to_root.C .

        # Create output filename
        set base = \`basename \$INPUTFILE0 .log\`
        set outfile = "\${base}.root"

        echo "Output will be: \$outfile"

        # Run ROOT
        root -l -b -q log_to_root.C\(\"\$INPUTFILE0\",\"\$outfile\"\)
    </command>

    <!-- Look for log files in your scratch directory -->
    <input URL="file:${OUT_DIR}/output_*.log" />

    <stdout URL="file:${OUT_DIR}/log/\$JOBID.out" />
    <stderr URL="file:${OUT_DIR}/log/\$JOBID.err" />

    <!-- Copy resulting ROOT files back to scratch -->
    <output fromScratch="*.root" toURL="file:${OUT_DIR}/" />

    <Generator>
        <Location>${OUT_DIR}/sched/</Location>
    </Generator>
</job>
EOF

    echo "[i] Submitting jobs using simple_root.xml..."
    star-submit "${WORK_DIR}/simple_root.xml"
    
    # Cleanup
    #rm "${WORK_DIR}/simple_root.xml"
    
    echo "[i] Done."
    exit 0
fi

echo "[!] Unknown mode: $MODE"
