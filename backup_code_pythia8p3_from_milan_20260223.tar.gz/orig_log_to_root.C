void log_to_root(){
    //TString infile = "/scratch/negishi/mstojano/ppcorr_tmp/MC/PythiaGen/output_1.log";
    //TString infile = "/scratch/negishi/mstojano/ppcorr/MC/PythiaGen_pubcuts/output200p_detroit0.log";
    TString infile = "/star/data01/pwg/ptribedy/pythia8p3_from_milan/output/output.log";

    std::ifstream fin(infile);
    if (!fin.is_open()) {
        std::cerr << "Cannot open file: " << infile << std::endl;
        return;
    }

    // Variables to hold the data
    float a, b, c, d, e, f, eccEt[1000], eccEta[1000], eccPhi[1000];
    int runNo, evtNo, eccMult;

    // Create output ROOT file and TTree
    //TString outfile = "/scratch/negishi/mstojano/ppcorr/MC/PythiaGen/output_detroit_1.root";
    TString outfile = "output.root";
    TFile* fout = new TFile(outfile, "RECREATE");
    TTree* tree = new TTree("tree", "Log data");
    //TTree *tree = new TTree("T","CERN 1988 staff data");

    TTree* m_T = new TTree("T", "Pythia Tree");
    m_T->Branch("RunNo",&runNo);
    m_T->Branch("EvtNo",&evtNo);

    m_T->Branch("eccMult",&eccMult);

    //m_T->Branch("eccE",eccE,"eccE[eccMult]/F");
    m_T->Branch("eccEt",eccEt,"eccEt[eccMult]/F");
    m_T->Branch("eccEta",eccEta,"eccEta[eccMult]/F");
    m_T->Branch("eccPhi",eccPhi,"eccPhi[eccMult]/F");

    // Read and fill tree
    f = 0;
    eccMult=0;
    while (fin >> a >> b >> c >> d >> e) {
            //tree->Fill();
        if (f!=a) {
            m_T->Fill();
            eccMult = 0;
            }
        eccEt[eccMult]=b;
        eccEta[eccMult]=c;
        eccPhi[eccMult]=d;
        eccMult++;
        f=a;
    }

    // Save and close
    m_T->Write();
    fout->Close();
    fin.close();
}

