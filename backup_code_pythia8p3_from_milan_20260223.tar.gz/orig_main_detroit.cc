// main101.cc is a part of the PYTHIA event generator.
// Copyright (C) 2025 Torbjorn Sjostrand.
// PYTHIA is licenced under the GNU GPL v2 or later, see COPYING for details.
// Please respect the MCnet Guidelines, see GUIDELINES for details.

// Keywords: basic usage; charged multiplicity

// This is a simple test program. It fits on one slide in a talk.
// It studies the charged multiplicity distribution at the LHC.

#include "Pythia8/Pythia.h"
#include "Pythia8Plugins/InputParser.h"

using namespace Pythia8;
int main(int argc, char* argv[]) {
	cout<<__LINE__<<endl;
	std::ofstream myFile;
	//      std::cout << "Program name: " << argv[1] << std::endl; 
	std::string existing_string = "./output/output";
	cout<<__LINE__<<endl;
	std::string combined_string = existing_string;// + argv[1];
	combined_string = combined_string+".log";
	cout<<combined_string<<endl;
	myFile.open(combined_string);

	cout<<__LINE__<<endl;

	//InputParser::Status status = ip.init(argc, argv);
	//if (status != InputParser::Valid) return status;

	// Generator. Process selection. LHC initialization. Histogram.
	Pythia pythia;
	cout<<__LINE__<<endl;

	pythia.readString("SoftQCD:inelastic = on");
	cout<<__LINE__<<endl;

	pythia.readString("Beams:eCM = 200.");
	// BeamA = proton.
	pythia.readString("Beams:idA = 2212");
	// BeamB = proton.
	pythia.readString("Beams:idB = 2212");
	//set random seed
	pythia.readString("Random:setSeed = on");
	//Detroit

	pythia.readString("PDF:pSet = 17");
	pythia.readString("MultipartonInteractions:bProfile = 2");
	pythia.readString("MultipartonInteractions:ecmRef = 200");
	pythia.readString("MultipartonInteractions:pT0Ref          = 1.40");
	pythia.readString("MultipartonInteractions:ecmPow          = 0.135");
	pythia.readString("MultipartonInteractions:coreRadius      = 0.56");
	pythia.readString("MultipartonInteractions:coreFraction    = 0.78");
	pythia.readString("ColourReconnection:range                = 5.4");

	int seed = 10;//atoi(argv[1]);
	string set_seed = "Random:seed ="+std::to_string(seed);
	pythia.readString(set_seed.c_str());

	cout<<__LINE__<<endl;

	// If Pythia fails to initialize, exit with error.
	if (!pythia.init()) return 1;
	Hist mult("charged multiplicity", 100, -0.5, 799.5);
	// Begin event loop. Generate event. Skip if error. List first one.
	for (int iEvent = 0; iEvent <100; ++iEvent) {
		if (!pythia.next()) continue;
		// Find number of all final charged particles and fill histogram.
		int nCharged = 0;
		for (int i = 0; i < pythia.event.size(); ++i)
			if (pythia.event[i].isFinal() && pythia.event[i].isCharged())
				++nCharged;
		mult.fill( nCharged );
		cout<<__LINE__<<endl;
		bool isSPhenix = false;
		bool isSPhenixF = false;
		bool isSPhenixB = false;
		bool isStar = false;
		bool isStarF = false;
		bool isStarB = false;

		for (int i = 0; i < pythia.event.size(); ++i) {
			if (pythia.event[i].isFinal() &&  pythia.event[i].pT()>0.1 && pythia.event[i].eta()<5. && pythia.event[i].eta()>3.4 ) isStarF = true; 
			if (pythia.event[i].isFinal() &&  pythia.event[i].pT()>0.1 && pythia.event[i].eta()<-3.4 && pythia.event[i].eta()>-5.0 ) isStarB = true; 

			if (pythia.event[i].isFinal() &&  pythia.event[i].pT()>0.1 && pythia.event[i].eta()<3.9 && pythia.event[i].eta()>3.1 ) isSPhenixF = true; 
			if (pythia.event[i].isFinal() &&  pythia.event[i].pT()>0.1 && pythia.event[i].eta()<-3.1 && pythia.event[i].eta()>-3.9 ) isSPhenixB = true; 
		}
		if (isStarB && isStarF) isStar=true;
		if (isSPhenixF && isSPhenixB) isSPhenix = true;

		for (int i = 0; i < pythia.event.size(); ++i) {
			//if (pythia.event[i].isFinal() && (pythia.event[i].isCharged()) && pythia.event[i].pT()>0.2 && fabs(pythia.event[i].eta())<2.5) {
			if (pythia.event[i].isFinal() && (pythia.event[i].isCharged()) && pythia.event[i].m() >= 0. && pythia.event[i].pT()>0.2 && (fabs(pythia.event[i].eta())<1.5 || (pythia.event[i].eta()> 2.5 && pythia.event[i].eta()<4.)  )) {
				myFile<<iEvent<<" "<< isStar <<" "<<isSPhenix<<" "<< pythia.event[i].pT()<<" "<< pythia.event[i].eta()<<" "<< pythia.event[i].phi()<<" "<< pythia.event[i].m() <<endl;
			}
			//if (pythia.event[i].id()==22) cout<<pythia.event[i].id()<<" "<<pythia.event[i].m()<<" "<<pythia.event[i].charge()<<" "<<pythia.event[i].pol()<<endl;
		}  
		cout<<__LINE__<<endl;

		// End of event loop. Statistics. Histogram. Done.
		}
		pythia.stat();
		cout << "Mult: " << mult;
		return 0;
	}
