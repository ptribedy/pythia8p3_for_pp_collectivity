#!/bin/bash

# ==============================================================================
# STAR SUBMIT SCRIPT
# Usage: 
#   1. Generate Logs:  ./submit_job.sh log [N_JOBS]
#   2. Convert to Root: ./submit_job.sh root
# ==============================================================================

if [[ -z "$1" ]]; then
    echo "Usage: $0 [log|root] [N_JOBS]"
    exit 1
fi

MODE="$1"
ARG2="$2"
WORK_DIR="$(pwd)"
OUT_DIR="/star/data05/scratch/ptribedy/pythia_pp200"

echo "[i] OUT_DIR: ${OUT_DIR}"

# ==============================================================================
# MODE 1: GENERATE LOGS (RUN PYTHIA)
# ==============================================================================
if [[ "$MODE" == "log" ]]; then
    
    # Default to 10 jobs if not specified
    NJOBS=${ARG2:-10}
    
    echo "[i] Mode: LOG GENERATION"
    echo "[i] Jobs to submit: ${NJOBS}"

    # 1. Compile Code First
    echo "[i] Compiling myPythia..."
    if ! command -v root-config &> /dev/null; then
        echo "[!] Warning: ROOT environment might not be loaded (setup 64bits)."
    fi
    
    g++ main_detroit.cc -I$OPTSTAR/include -L$OPTSTAR/lib -lpythia8 -std=c++11 -o myPythia
    if [ $? -ne 0 ]; then echo "[!] Compilation failed."; exit 1; fi

    # 2. Create Directories
    mkdir -p "${OUT_DIR}/log"
    mkdir -p "${OUT_DIR}/sched"

    # 3. Generate XML
    # We use nProcesses because we are generating events from scratch
    cat <<EOF > "${WORK_DIR}/simple_log.xml"
<?xml version="1.0" encoding="utf-8" ?>
<job name="PythiaGen" nProcesses="${NJOBS}" filesPerHour="5" simulateSubmission="false">
    
    <command>
        <!-- 1. Setup STAR Environment -->
        setup 64bits
        setup nfs4

        <!-- 2. Prepare Directory Structure -->
        <!-- Code expects ./output/ folder to exist -->
        mkdir output

        <!-- 3. Copy Executable -->
        cp ${WORK_DIR}/myPythia .

        <!-- 4. Run the code -->
        <!-- We use \$JOBINDEX as the Seed -->
        echo "Running Job Index (Seed): \$JOBINDEX"
        ./myPythia \$JOBINDEX

    </command>

    <!-- 5. Output Management -->
    <!-- Save the .log file from ./output/ to scratch -->
    <output fromScratch="output*.log" toURL="file:${OUT_DIR}/" />

    <!-- Standard logs -->
    <stdout URL="file:${OUT_DIR}/log/gen_\$JOBID.out" />
    <stderr URL="file:${OUT_DIR}/log/gen_\$JOBID.err" />

    <Generator>
        <Location>${OUT_DIR}/sched/</Location>
    </Generator>
</job>
EOF

    # 4. Submit
    echo "[i] Submitting jobs using simple_log.xml..."
    star-submit "${WORK_DIR}/simple_log.xml"
    
    # Cleanup
    rm "${WORK_DIR}/simple_log.xml"
    
    echo "[i] Done. Logs will appear in ${OUT_DIR}"
    exit 0
fi

# ==============================================================================
# MODE 2: CONVERT LOGS TO ROOT
# ==============================================================================
if [[ "$MODE" == "root" ]]; then

    echo "[i] Mode: ROOT CONVERSION"

    if [[ ! -f "${WORK_DIR}/log_to_root.C" ]]; then
        echo "[!] log_to_root.C not found!"
        exit 1
    fi

    mkdir -p "${OUT_DIR}/log"
    mkdir -p "${OUT_DIR}/sched"

    # Generate XML for processing existing files
    cat <<EOF > "${WORK_DIR}/simple_root.xml"
<?xml version="1.0" encoding="utf-8"?>
<job name="PythiaRoot" maxFilesPerProcess="1" fileListSyntax="paths" simulateSubmission="false">

    <command>
        setup 64bits
        setup nfs4
        
        echo "Processing: \$INPUTFILE0"

        cp ${WORK_DIR}/log_to_root.C .

        set base = \`basename \$INPUTFILE0 .log\`
        set outfile = "\${base}.root"

        echo "Output will be: \$outfile"

        # Run ROOT with double-escaped quotes for CSH
        root -l -b -q log_to_root.C\(\"\$INPUTFILE0\",\"\$outfile\"\)
    </command>

    <input URL="file:${OUT_DIR}/output_*.log" />

    <stdout URL="file:${OUT_DIR}/log/conv_\$JOBID.out" />
    <stderr URL="file:${OUT_DIR}/log/conv_\$JOBID.err" />

    <output fromScratch="*.root" toURL="file:${OUT_DIR}/" />

    <Generator>
        <Location>${OUT_DIR}/sched/</Location>
    </Generator>
</job>
EOF

    echo "[i] Submitting jobs using simple_root.xml..."
    star-submit "${WORK_DIR}/simple_root.xml"
    
    # Cleanup
    rm "${WORK_DIR}/simple_root.xml"
    
    echo "[i] Done."
    exit 0
fi

echo "[!] Unknown mode: $MODE"
echo "Usage: $0 [log|root] [N_JOBS]"
