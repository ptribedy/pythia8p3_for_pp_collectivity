#include <iostream>
#include <vector>
#include <cmath>

#include "TFile.h"
#include "TChain.h"
#include "TTree.h"
#include "TH1D.h"
#include "TH2D.h"
#include "TProfile.h"
#include "TRandom3.h"
#include "TMath.h"

#include <fstream>
#include "TObjArray.h"
#include "TObjString.h"



using namespace std;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

const int nCentBins = 9;

const int nPtBins  = 9;
const double ptMin = 0.2;
const double ptMax = 2.0;

// ---------------------
// Centrality function
// ---------------------
int GetCentrality(int mult) {
	if (mult > 25) return 0;
	if (mult > 20) return 1;
	if (mult > 16) return 2;
	if (mult > 13) return 3;
	if (mult > 10) return 4;
	if (mult > 7)  return 5;
	if (mult > 5)  return 6;
	if (mult > 3)  return 7;
	if (mult > 1)  return 8;
	return -1;
}

// ---------------------
// pT binning
// ---------------------
int GetPtBin(double pt) {
	if (pt < ptMin || pt >= ptMax) return -1;
	double width = (ptMax - ptMin) / nPtBins;
	int bin = static_cast<int>((pt - ptMin) / width);
	if (bin < 0 || bin >= nPtBins) return -1;
	return bin;
}

// ==========================================================================
//                                 MAIN
// ==========================================================================

void flowanalysis(TString inputFiles, TString outputFile) {

	// Build TChain from either:
	//  1) a .list file (one ROOT path per line), or
	//  2) a space-separated list of ROOT paths
	TChain *chain = new TChain("tree");

	// Case 1: inputFiles is a single ".list" file
	if (inputFiles.EndsWith(".list")) {
		cout << "Reading input file list from: " << inputFiles << endl;
		ifstream fin(inputFiles.Data());
		if (!fin.is_open()) {
			cout << "Error: cannot open list file " << inputFiles << endl;
			return;
		}
		std::string line;
		while (std::getline(fin, line)) {
			TString fname(line.c_str());
			fname = fname.Strip(TString::kBoth, ' ');
			if (fname.Length() == 0) continue;
			cout << "  " << fname << endl;
			chain->Add(fname);
		}
		fin.close();
	} else {
		// Case 2: space-separated list of ROOT paths in a single string
		cout << "Adding input files to chain from space-separated string:" << endl;
		cout << "  [" << inputFiles << "]" << endl;

		TObjArray *tokens = inputFiles.Tokenize(" ");
		int nTokens = tokens ? tokens->GetEntriesFast() : 0;

		for (int i = 0; i < nTokens; ++i) {
			TObjString *os = dynamic_cast<TObjString*>(tokens->At(i));
			if (!os) continue;
			TString fname = os->GetString();
			fname = fname.Strip(TString::kBoth, ' ');
			if (fname.Length() == 0) continue;
			cout << "  " << fname << endl;
			chain->Add(fname);
		}
		delete tokens;
	}

	if (!chain->GetEntries()) {
		cout << "Error: No entries found in any input files!" << endl;
		return;
	}

	cout << "Total events in chain: " << chain->GetEntries() << endl;

	//
	//
vector<float> *v_pt  = 0;
vector<float> *v_eta = 0;
vector<float> *v_phi = 0;
vector<int>   *v_charge = 0;
int nTracks = 0;


	chain->SetBranchAddress("nTracks", &nTracks);
	chain->SetBranchAddress("pT",     &v_pt);
	chain->SetBranchAddress("eta",    &v_eta);
	chain->SetBranchAddress("phi",    &v_phi);
	chain->SetBranchAddress("charge", &v_charge);

	TFile *fOut = new TFile(outputFile, "RECREATE");

	// ================= QA HISTS ===================
	TH1D *hRefMult = new TH1D("hRefMult",
			"RefMult;Multiplicity;",
			100, -0.5, 99.5);

	TH1D *hTofMult = new TH1D("hTofMult",
			"TOF Mult;Multiplicity;",
			100, -0.5, 99.5);

	// ================= Δη–Δφ HISTS ===============
	TH2D *detadphi[nCentBins];
	TH2D *detadphi_os[nCentBins];
	TH2D *detadphi_ss[nCentBins];

	for (int c = 0; c < nCentBins; c++) {

		detadphi[c] = new TH2D(
				Form("detadphi_%d", c),
				Form("Cent %d;#Delta#eta;", c),
				100, -3.0, 3.0,
				100, -M_PI/2, 3*M_PI/2
				);

		detadphi_os[c] = new TH2D(
				Form("detadphi_os_%d", c),
				Form("Cent %d OS;#Delta#eta;", c),
				100, -3.0, 3.0,
				100, -M_PI/2, 3*M_PI/2
				);

		detadphi_ss[c] = new TH2D(
				Form("detadphi_ss_%d", c),
				Form("Cent %d SS;#Delta#eta;", c),
				100, -3.0, 3.0,
				100, -M_PI/2, 3*M_PI/2
				);

		detadphi[c]->Sumw2();
		detadphi_os[c]->Sumw2();
		detadphi_ss[c]->Sumw2();
	}

	// ================= TRIGGER COUNTERS ===============
	TH2D *Ntrig_detadphi = new TH2D(
			"Ntrig_detadphi",
			"N_{trig};p_{T} bin index;",
			nPtBins, -0.5, nPtBins - 0.5,
			nCentBins, -0.5, nCentBins - 0.5
			);

	TH1D *Ntrig_detadphi_eventcount = new TH1D(
			"Ntrig_detadphi_eventcount",
			"Event count;Centrality;",
			nCentBins, -0.5, nCentBins - 0.5
			);

	// ================= v_n2 PROFILES (all, OS, SS) ===============
	TProfile *v12tpc     = new TProfile("v12tpc",
			"v_{1}^{2} (TPC all);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v22tpc     = new TProfile("v22tpc",
			"v_{2}^{2} (TPC all);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v32tpc     = new TProfile("v32tpc",
			"v_{3}^{2} (TPC all);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);

	TProfile *v12tpc_os  = new TProfile("v12tpc_os",
			"v_{1}^{2} (TPC OS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v22tpc_os  = new TProfile("v22tpc_os",
			"v_{2}^{2} (TPC OS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v32tpc_os  = new TProfile("v32tpc_os",
			"v_{3}^{2} (TPC OS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);

	TProfile *v12tpc_ss  = new TProfile("v12tpc_ss",
			"v_{1}^{2} (TPC SS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v22tpc_ss  = new TProfile("v22tpc_ss",
			"v_{2}^{2} (TPC SS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);
	TProfile *v32tpc_ss  = new TProfile("v32tpc_ss",
			"v_{3}^{2} (TPC SS);Centrality;",
			nCentBins, -0.5, nCentBins - 0.5);

	v12tpc->Sumw2();    v22tpc->Sumw2();    v32tpc->Sumw2();
	v12tpc_os->Sumw2(); v22tpc_os->Sumw2(); v32tpc_os->Sumw2();
	v12tpc_ss->Sumw2(); v22tpc_ss->Sumw2(); v32tpc_ss->Sumw2();

	// ======================================================================
	//                              EVENT LOOP
	// ======================================================================
	Long64_t nEvents = chain->GetEntries();

	for (Long64_t iev = 0; iev < nEvents; iev++) {
		chain->GetEntry(iev);

		int itpcMult = 0;
		int bTOF     = 0;

		if (!v_pt || v_pt->size() != (unsigned)nTracks) continue;


		// multiplicity for centrality, QA
		for (int i = 0; i < nTracks; i++) {
			double pt  = v_pt->at(i);
			double eta = v_eta->at(i);
			if (pt < 0.2) continue;
			if (fabs(eta) < 1.5) itpcMult++;
			if (fabs(eta) < 0.9) bTOF++;
		}

		hRefMult->Fill(itpcMult);
		hTofMult->Fill(bTOF);

		int centBin = GetCentrality(itpcMult);

		if(iev%1000==0)cout<<" event "<<iev<<" trak= "<<nTracks<<" centBin "<<centBin<<" itpcMult "<<itpcMult<<endl; 

		if (centBin < 0) continue;

		Ntrig_detadphi_eventcount->Fill(centBin);

		// ------------- v_n2 accumulators for THIS EVENT (all, OS, SS) ------
		double sumCos1_all = 0, sumCos2_all = 0, sumCos3_all = 0;
		double sumCos1_os  = 0, sumCos2_os  = 0, sumCos3_os  = 0;
		double sumCos1_ss  = 0, sumCos2_ss  = 0, sumCos3_ss  = 0;

		int countLR_all = 0;
		int countLR_os  = 0;
		int countLR_ss  = 0;

		// Trigger–associate loops
		for (int i = 0; i < nTracks; i++) {

			double pti  = v_pt->at(i);
			double etai = v_eta->at(i);

			if (pti < 0.2 || pti > 2.0 || fabs(etai) > 1.0) continue;

			int ptiBin = GetPtBin(pti);
			if (ptiBin >= 0) Ntrig_detadphi->Fill(ptiBin, centBin);

			for (int j = 0; j < nTracks; j++) {
				if (i == j) continue;

				double ptj  = v_pt->at(j);
				double etaj = v_eta->at(j);
				if (ptj < 0.2 || ptj > 2.0 || fabs(etaj) > 1.0) continue;

				double dEta = etai - etaj;
				double dPhi = v_phi->at(i) - v_phi->at(j);

				if (dPhi < -M_PI/2)      dPhi += 2*M_PI;
				else if (dPhi > 3*M_PI/2) dPhi -= 2*M_PI;

				detadphi[centBin]->Fill(dEta, dPhi);

				bool isOS = (v_charge->at(i) != v_charge->at(j));
				if (isOS)
					detadphi_os[centBin]->Fill(dEta, dPhi);
				else
					detadphi_ss[centBin]->Fill(dEta, dPhi);

				// Long-range region for flow
				if (fabs(dEta) > 1.3) {
					double c1 = cos(1.0 * dPhi);
					double c2 = cos(2.0 * dPhi);
					double c3 = cos(3.0 * dPhi);

					// all pairs
					sumCos1_all += c1;
					sumCos2_all += c2;
					sumCos3_all += c3;
					countLR_all++;

					// OS / SS split
					if (isOS) {
						sumCos1_os += c1;
						sumCos2_os += c2;
						sumCos3_os += c3;
						countLR_os++;
					} else {
						sumCos1_ss += c1;
						sumCos2_ss += c2;
						sumCos3_ss += c3;
						countLR_ss++;
					}
				}
			}
		}

		// ----- Fill v_n2 profiles for this event (all, OS, SS) -----

		// -------- ALL CHARGES --------
		if (countLR_all > 0) {

			double v12tpc_evt = sumCos1_all / countLR_all;
			double v22tpc_evt = sumCos2_all / countLR_all;
			double v32tpc_evt = sumCos3_all / countLR_all;

			v12tpc->Fill(centBin, v12tpc_evt);
			v22tpc->Fill(centBin, v22tpc_evt);
			v32tpc->Fill(centBin, v32tpc_evt);
		}

		// -------- OPPOSITE SIGN --------
		if (countLR_os > 0) {

			double v12tpc_evt_os = sumCos1_os / countLR_os;
			double v22tpc_evt_os = sumCos2_os / countLR_os;
			double v32tpc_evt_os = sumCos3_os / countLR_os;

			v12tpc_os->Fill(centBin, v12tpc_evt_os);
			v22tpc_os->Fill(centBin, v22tpc_evt_os);
			v32tpc_os->Fill(centBin, v32tpc_evt_os);
		}

		// -------- SAME SIGN --------
		if (countLR_ss > 0) {

			double v12tpc_evt_ss = sumCos1_ss / countLR_ss;
			double v22tpc_evt_ss = sumCos2_ss / countLR_ss;
			double v32tpc_evt_ss = sumCos3_ss / countLR_ss;

			v12tpc_ss->Fill(centBin, v12tpc_evt_ss);
			v22tpc_ss->Fill(centBin, v22tpc_evt_ss);
			v32tpc_ss->Fill(centBin, v32tpc_evt_ss);
		}

		if(iev%1000==0)cout<<" event "<<iev<<" trak= "<<nTracks<<" v12, v22,v32, "<<v12tpc_evt<<" "<<v22tpc_evt<<" "<<v32tpc_evt<<endl;
	}

	fOut->Write();
	fOut->Close();
}

